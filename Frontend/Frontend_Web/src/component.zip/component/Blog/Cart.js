import React, { use, useContext, useEffect, useState } from 'react'
import API from '../Config/Config'
import { AppContext } from '../Context/AppContext'
import { useDispatch } from 'react-redux'


export default function Cart() {

  // const {updateCartCount} = useContext(AppContext)

    const [getCart, setCart] = useState([])
    const dispatch = useDispatch()
   
  
    useEffect(() =>{

        let cart = JSON.parse(localStorage.getItem("cart"))
        console.log("cart",cart)
        API.post('/product/cart', cart)
        .then(res => {
            console.log("getCart" , res.data.data)
            setCart(res.data.data)
        }
            
        )
    },[])
    function qtyUp(id){
       dispatch({
        type: "ADD_CART",
        payload:id
      })
     

      let newCart = [...getCart];
     newCart.map((value, key) => {
        if(value.id === id){
          newCart[key].qty++
          
        }
      })
      console.log("qty", newCart)
      setCart(newCart)
      
        // updateCartCount()
    

      }
      function qtyDown(id){
         dispatch({
          type: "DOWN_CART",
          payload:id
        })
       
         let newCart1 = [...getCart];
        newCart1.map((value, key)=>{
          if(value.id === id){
            if(value.qty > 1){
                newCart1[key].qty--
               
            }else{
              qtyDelete(value.id)
            }
          
          }
        })
          
      console.log("qty", newCart1)
      setCart(newCart1)
    
      // updateCartCount()
      
      }

    //      function qtyDelete(id) {
    //         let newCart2 = [...getCart];
    //   const updatedCart = newCart2.filter(item => item && item.id !== id)
    //   setCart(updatedCart)
    //   localStorage.setItem("cart", JSON.stringify());

    //   console.log("Giỏ hàng sau khi xóa:", updatedCart);
    // }
    function qtyDelete(id) {
       dispatch({
          type: "DELETE_CART",
          payload:id
        })
      const updatedStateCart = getCart.filter(item => item && item.id !== id)
      setCart(updatedStateCart)
      let storageCart = JSON.parse(localStorage.getItem("cart"));
      
      if (storageCart) {
        delete storageCart[id]
        localStorage.setItem("cart", JSON.stringify(storageCart));
      }
      // updateCartCount()

      console.log("Đã xóa ID:", id);
    }

 


    
    function fetchData(e){
      if(!getCart) return null
      if(getCart && getCart.length > 0){
        return getCart.map((value,index) =>{
          let image = JSON.parse(value.image)
          return (
             <tr key={value.id}>
                    <td className="cart_product">
                      <a  href><img style={{width:"100px"}} src={"http://localhost/laravel8/laravel8/public/upload/product/" + value.id_user + "/" + image[0]} alt="" /></a>
                    </td>
                    <td className="cart_description">
                      <h4><a href>{value.name}</a></h4>
                      <p>Web ID: {value.web_id}</p>
                    </td>
                    <td className="cart_price">
                      <p>{value.price}</p>
                    </td>
                    <td className="cart_quantity">
                      <div className="cart_quantity_button">
                        <a className="cart_quantity_up" onClick={() => qtyUp(value.id)} id={value.id} > + </a>
                        <input className="cart_quantity_input" type="text" name="quantity" value={value.qty} autoComplete="off" size={2} />
                        <a className="cart_quantity_down" onClick={() => qtyDown(value.id)}  href> - </a>
                      </div>
                    </td>
                    <td className="cart_total">
                      <p className="cart_total_price" >{value.price * value.qty}</p>
                    </td>
                    <td className="cart_delete">
                      <a className="cart_quantity_delete" onClick={() => qtyDelete(value.id)}  href><i className="fa fa-times" /></a>
                    </td>
                  </tr>
                  
)
        })
      }
    }
    // Tính tổng tiền hàng (Sub Total)
        const subTotal = getCart.reduce((total, item) => {
            return total + (item.price * item.qty);
        }, 0);

        
        const ecoTax = 2;

        
        const finalTotal = subTotal + ecoTax;
  return (
     <div>
        <section id="cart_items">
          <div className="container">
            <div className="breadcrumbs">
              <ol className="breadcrumb">
                <li><a href="#">Home</a></li>
                <li className="active">Shopping Cart</li>
              </ol>
            </div>
            <div className="table-responsive cart_info">
              <table className="table table-condensed">
                <thead>
                  <tr className="cart_menu">
                    <td className="image">Item</td>
                    <td className="description" />
                    <td className="price">Price</td>
                    <td className="quantity">Quantity</td>
                    <td className="total">Total</td>
                    <td />
                  </tr>
                </thead>
                <tbody id="cart_tbody">
                  {fetchData()}

                </tbody>
              </table>
            </div>
          </div>
        </section> {/*/#cart_items*/}
        <section id="do_action">
          <div className="container">
            <div className="heading">
              <h3>What would you like to do next?</h3>
              <p>Choose if you have a discount code or reward points you want to use or would like to estimate your delivery cost.</p>
            </div>
            <div className="row">
              <div className="col-sm-6">
                <div className="chose_area">
                  <ul className="user_option">
                    <li>
                      <input type="checkbox" />
                      <label>Use Coupon Code</label>
                    </li>
                    <li>
                      <input type="checkbox" />
                      <label>Use Gift Voucher</label>
                    </li>
                    <li>
                      <input type="checkbox" />
                      <label>Estimate Shipping &amp; Taxes</label>
                    </li>
                  </ul>
                  <ul className="user_info">
                    <li className="single_field">
                      <label>Country:</label>
                      <select>
                        <option>United States</option>
                        <option>Bangladesh</option>
                        <option>UK</option>
                        <option>India</option>
                        <option>Pakistan</option>
                        <option>Ucrane</option>
                        <option>Canada</option>
                        <option>Dubai</option>
                      </select>
                    </li>
                    <li className="single_field">
                      <label>Region / State:</label>
                      <select>
                        <option>Select</option>
                        <option>Dhaka</option>
                        <option>London</option>
                        <option>Dillih</option>
                        <option>Lahore</option>
                        <option>Alaska</option>
                        <option>Canada</option>
                        <option>Dubai</option>
                      </select>
                    </li>
                    <li className="single_field zip-field">
                      <label>Zip Code:</label>
                      <input type="text" />
                    </li>
                  </ul>
                  <a className="btn btn-default update" href>Get Quotes</a>
                  <a className="btn btn-default check_out" href>Continue</a>
                </div>
              </div>
              <div className="col-sm-6">
                <div className="total_area">
                  <ul>
                    <li className="cart_sub_total">Cart Sub Total <span>{subTotal}</span></li>
                    <li className="eco_tax">Eco Tax <span>{ecoTax}</span></li>
                    <li>Shipping Cost <span>Free</span></li>
                    <li className="total_all">Total <span>{finalTotal}</span></li>
                  </ul>
                  <a className="btn btn-default update" href>Update</a>
                  <a className="btn btn-default check_out" href>Check Out</a>
                </div>
              </div>
            </div>
          </div>
        </section>{/*/#do_action*/}
      </div>
  )
}

