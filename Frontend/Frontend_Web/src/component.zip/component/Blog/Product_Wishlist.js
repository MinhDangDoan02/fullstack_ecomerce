import React, { useContext, useEffect, useState } from 'react'
import API from '../Config/Config'
import { AppContext } from '../Context/AppContext';

export default function Product_Wishlist() {
    const [wishListProducts, setWishListProducts] = useState([])
    const {updateWishList} = useContext(AppContext)

    useEffect(() => {

        const wishlistData = JSON.parse(localStorage.getItem("wishlist")) || {};
      
        const favoriteIds = Object.keys(wishlistData)

        if (favoriteIds.length > 0) {
            // goi toan bo san pham ra
            API.get("/product/wishlist")
                .then(res => {
                    const allProducts = res.data.data
                    // chi lay nhung san pham co id trong favourites
                    const filtered = allProducts.filter(item => 
                        favoriteIds.includes(item.id.toString())
                       
                    )

                    setWishListProducts(filtered)
                })
                
        }
    }, []);

    // xoa san pham khoi wishlist
   function removeWishlist(id){
    let prd_WishList = JSON.parse(localStorage.getItem("wishlist"))
    delete prd_WishList[id]

    let productsWishList = wishListProducts.filter(item => item && item.id !== id)
    setWishListProducts(productsWishList)
    localStorage.setItem("wishlist",JSON.stringify(prd_WishList))
    updateWishList()

   }

    function renderWishlist() {
        if (wishListProducts.length > 0) {
            return wishListProducts.map((value) => {
                let images = JSON.parse(value.image);
                return (
                    <tr key={value.id}>
                        <td className="cart_product">
                            <img 
                                src={"http://localhost/laravel8/laravel8/public/upload/product/" + value.id_user + "/" + images[0]} 
                                style={{width: "80px"}} 
                                alt="" 
                            />
                        </td>
                        <td className="cart_description">
                            <h4>{value.name}</h4>
                            <p>Web ID: {value.id}</p>
                        </td>
                        <td className="cart_price">
                            <p>${value.price}</p>
                        </td>
                        <td className="cart_delete">
                            <a className="cart_quantity_delete" onClick={() => removeWishlist(value.id)}>
                                <i className="fa fa-times" />
                            </a>
                        </td>
                    </tr>
                )
            })
        } else {
            return <tr><td colSpan="4"><p className="text-center">Wishlist is empty</p></td></tr>
        }
    }

    return (
        <section id="cart_items">
            <div className="container">
                <div className="table-responsive cart_info">
                    <table className="table table-condensed">
                        <thead>
                            <tr className="cart_menu">
                                <td className="image">Item</td>
                                <td className="description">Name</td>
                                <td className="price">Price</td>
                                <td />
                            </tr>
                        </thead>
                        <tbody>
                            {renderWishlist()}
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    )
}