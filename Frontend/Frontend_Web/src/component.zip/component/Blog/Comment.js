import axios from 'axios'
import React, { useState } from 'react'
import API from '../Config/Config'
import ListCmt from './ListCmt'
import Detail from './Detail'


export default function Comment(props) {
  const [inputs, setInputs] = useState({
    message:""
  })
  function handleInput(e){
    e.preventDefault()
    const name = e.target.name
    const value = e.target.value
    setInputs(state =>({... state,
      [name]:value
    }))
  }

  let auth = localStorage.getItem("user")
  if(auth){
    auth = JSON.parse(auth)
  }
  const [errors, setErrors] = useState({})
  function handleSubmit(e){
    e.preventDefault()
    let errorSubmit = {}
    let flag = true

    if(auth){
      if(inputs.message ==""){
        errorSubmit.message = "vui long nhap binh luan"
        flag= false
      }
    }
    if(!auth){
      errorSubmit.message = "vui long login"
      flag = false
    }
    if(!flag){
      setErrors(errorSubmit)
    }
     let token = JSON.parse(localStorage.getItem("token"))
   
    let config = { 
                headers: { 
                'Authorization': 'Bearer '+ token,
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/json'
                } 
            };
  
      const formData = new FormData()
        formData.append('id_blog', props.id_blog)
        formData.append('id_user', auth.id)
        formData.append('comment', inputs.message)
        formData.append('image_user', auth.avatar)
        formData.append('name_user', auth.name)
        formData.append('id_comment', props.id_comment ? props.id_comment : 0)

        console.log("id_comment gui:", props.id_comment)

        API.post("/blog/comment/" + props.id_blog,formData,config)
        .then(res =>{
          console.log(res)
          alert("thanh cong")
          //postCommet sang Detail
          const data = res.data.data
          console.log("aaaaaaaa", data)
            props.getCmt({...data,
              id_comment: props.id_comment || 0})
        })
    

        
    

  }
   function renderError(){
      if(Object.keys(errors).length > 0){
        return Object.keys(errors).map((key, index) => 
          {
           return  (
            <li key={index}>{errors[key]}</li>
        )
        })
      }
    }
   


  return (
    
        <div 

        className="replay-box">
    <div className="row">
    <div className="col-sm-12">
      <h2>Leave a reply</h2>
      {renderError()}

      <div className="text-area">
        <div className="blank-arrow">
          <label htmlFor="message">Your Name</label>
        </div>
        <span>*</span>
        <textarea
          id="message"
          name="message"
          rows={11}
          
          onChange={handleInput}
        />
        <button className="btn btn-primary"  onClick={handleSubmit}>
          Post Comment
        </button>
      </div>
    </div>
  </div>

  
</div>
  )
}
